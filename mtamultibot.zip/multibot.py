import cv2
import numpy as np
from ultralytics import YOLO
import mss
import pygetwindow as gw
import interception
import time
import threading
import os
import sys
import math
import random
import pyautogui
from colorama import Fore, Back, Style

# Define the path to the internal folder
INTERNAL_FOLDER = "internal"

# YOLO model initialization (adjust the path to the internal folder)
ai = os.path.join(INTERNAL_FOLDER, "best.pt")
model = YOLO(ai)

KEY_MAPPINGS = {
    'q': 0,  
    'e': 1,  
}

# Paths to images (adjust the path to the internal folder)
l2_template_path = os.path.join(INTERNAL_FOLDER, 'l2.png')
l2_template = cv2.imread(l2_template_path, cv2.IMREAD_GRAYSCALE)
l2_w, l2_h = l2_template.shape[::-1]

debug = False  # Toggle logging

def press_key(key):
    """Simulate key press."""
    print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Pressed {key}")
    interception.press(key)

def predict_and_detect_with_yolov8(frame, confidence=0.5):
    """Detect objects in the frame using YOLOv8."""
    results = model(frame)
    predictions = results[0].boxes.xyxy.cpu().numpy()
    confidences = results[0].boxes.conf.cpu().numpy()
    class_ids = results[0].boxes.cls.cpu().numpy()

    for i, (x1, y1, x2, y2) in enumerate(predictions):
        if confidences[i] > confidence:
            class_id = int(class_ids[i])
            if class_id == KEY_MAPPINGS['q']:
                press_key("e")
            elif class_id == KEY_MAPPINGS['e']:
                press_key("q")

def detect_l2_key(frame):
    """Detect the 'L2' key on screen using template matching."""
    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    result = cv2.matchTemplate(gray_frame, l2_template, cv2.TM_CCOEFF_NORMED)
    threshold = 0.8
    locations = np.where(result >= threshold)
    if len(locations[0]) > 0:
        if debug:
            print(f"{Fore.CYAN}[DEBUG]{Style.RESET_ALL} L2 detected!")
        press_key("altleft")

def capture_screen():
    """Capture the screen and process it for object detection."""
    with mss.mss() as sct:
        monitor = sct.monitors[1]  # Primary screen
        while True:
            screen = np.array(sct.grab(monitor))
            frame = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
            predict_and_detect_with_yolov8(frame, confidence=0.4)
            detect_l2_key(frame)

def find_image_on_screen(target_image_path, threshold=0.8):
    """Find a specific image on the screen."""
    target_image = cv2.imread(target_image_path, cv2.IMREAD_GRAYSCALE)
    if target_image is None:
        raise FileNotFoundError(f"Image not found: {target_image_path}")
    screen = pyautogui.screenshot()
    screen_np = np.array(screen)
    screen_bgr = cv2.cvtColor(screen_np, cv2.COLOR_RGB2BGR)
    screen_gray = cv2.cvtColor(screen_bgr, cv2.COLOR_BGR2GRAY)
    result = cv2.matchTemplate(screen_gray, target_image, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    if max_val >= threshold:
        return max_loc
    return None

def handle_images(images_list):
    """Handle actions based on detected images."""
    for image_path in images_list:
        image_full_path = os.path.join(INTERNAL_FOLDER, image_path)
        location = find_image_on_screen(image_full_path)
        if location:
            print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Found '{image_path}', performing action.")
            if image_path == "end.png":
                interception.press("i")
                time.sleep(1)
                location_123 = find_image_on_screen("123.png")
                if location_123:
                    pyautogui.moveTo(location_123[0], location_123[1])
                    interception.click(button="right")
                    time.sleep(1)
                    location_ok = find_image_on_screen("ok.png")
                    if location_ok:
                        pyautogui.moveTo(location_ok[0], location_ok[1])
                        interception.click(button="left")
                        time.sleep(1)
                        interception.press("i")
                        time.sleep(1)
                        interception.click(button="left")
            elif image_path == "zjd.png":
                interception.click(button="left")
                time.sleep(5)
                interception.click(button="left")
            elif image_path == "afk.png":
                interception.click(button="left")
                time.sleep(1)

def outmta_bot():
    """Main function for handling outmta bot actions."""
    images_list = [
        "end.png", "zjd.png", "afk.png", "123.png", "ok.png"
    ]
    
    def main():
        print(f"{Fore.YELLOW}[INFO]{Style.RESET_ALL} Starting real-time screen image detection. Press Ctrl+C to stop.")
        try:
            while True:
                handle_images(images_list)
        except KeyboardInterrupt:
            print(f"\n{Fore.RED}[INFO]{Style.RESET_ALL} Exiting...")

    if __name__ == "__main__":
        main()

def show_main_menu():
    """Display the main menu."""
    os.system("cls")
    os.system("title Professional MTA Bot Menu")
    print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
    print(f"{Fore.GREEN}[ 4Life MTA Bot Menu ]{Style.RESET_ALL}".center(50))
    print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
    print(f"\n{Fore.YELLOW}[ 1 ] Start Miner")
    print(f"{Fore.YELLOW}[ 2 ] Toggle Debugging")
    print(f"{Fore.YELLOW}[ 3 ] Start outmta bot")
    print(f"{Fore.YELLOW}[ 4 ] Exit")
    print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
    choice = input(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Enter your choice: ")

    return choice

def main():
    """Main driver function for the menu and bot actions."""
    global debug

    while True:
        choice = show_main_menu()
        
        if choice == "1":
            print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Starting miner...")
            print(f"{Fore.YELLOW}[INFO]{Style.RESET_ALL} Initializing screen capture...")
            capture_thread = threading.Thread(target=capture_screen)
            capture_thread.daemon = True
            capture_thread.start()
            print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Miner started successfully.")
            print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Press [Ctrl+C] to stop the miner.")
        elif choice == "2":
            debug = not debug
            print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Debugging {'enabled' if debug else 'disabled'}.")
        elif choice == "3":
            print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Starting outmta bot...")
            outmta_bot()
        elif choice == "4":
            print(f"{Fore.RED}[INFO]{Style.RESET_ALL} Exiting... Goodbye.")
            break
        else:
            print(f"{Fore.RED}[ERROR]{Style.RESET_ALL} Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
